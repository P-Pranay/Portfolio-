# Pranay Kumar — HRMS Product Specialist

Professional portfolio: payroll, attendance, leave and HRMS implementation delivery.

**Live site:** https://p-pranay.github.io/Portfolio-/

## What's here

- `index.html` — the complete portfolio, self-contained (all CSS inline, no dependencies, no build step)
- `.nojekyll` — tells GitHub Pages to serve the files as-is

## Updating it

Edit `index.html`, then:

```bash
git add -A
git commit -m "Update portfolio"
git push
```

GitHub Pages redeploys automatically in under a minute.

---
38 HRMS implementations · 7,093 employees · 24 industries · 16 cities
